=== Social Block ===
Contributors: Shelob9, easilyamused, blockswp
Requires at least: 4.9.1
Tested up to: 4.9.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Super social share block for the new Gutenberg post editor.

== Description ==
Super social share block for the new Gutenberg post editor.

> A fun new plugin from [BlocksWP](https://blockswp.com/) - a partnership of [Caldera Labs](http://CalderLabs.org] and [Easily Amused](https://easilyamusedinc.com/).

= Supported Networks =
* Facebook
* Twitter
* Reddit
* LinkedIn
* Pinterest
* WhatsApp
* Tumblr
* Email

== Changelog ==
= 1.0.0 =
* Initial release to WordPress.org

== Installation ==
* Install and activate [Gutenberg](https://wordpress.org/plugins/gutenberg)
* Install and activate this plugin


== Frequently Asked Questions ==
= How Does It Work? =
* In the editor, click the plus button to add a block, search for "Social Share" and add that block.
* Select which networks to show.
* Set your other options.