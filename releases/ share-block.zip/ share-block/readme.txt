=== Social Block ===
Contributors: Shelob9
Requires at least: 4.9.1
Tested up to: 4.9.1
Stable tag: 0.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Super social share block for the new Gutenberg post editor.
== Description ==
Super social share block for the new Gutenberg post editor.

= Supported Networks =
* Facebook
* Twitter

== Changelog ==
= 0.1.0

== Installation ==
* Install and activate [Gutenberg](https://wordpress.org/plugins/gutenberg)
* Install and activate this plugin


== Frequently Asked Questions ==
= How Does It Work? =
* In the editor, click the plus button to add a block, search for "Social Share" and add that block.
* Select which networks to show.
* Set your other options.